from fastapi import FastAPI,Body,Path,Query,Form,status,Depends
from typing import List,Optional
from pydantic import BaseModel,Field,EmailStr
from datetime import date,datetime,time
from fastapi.responses import JSONResponse
from arango import ArangoClient
from fastapi_mail import FastMail,ConnectionConfig,MessageSchema
from fastapi.middleware.cors import CORSMiddleware
from temp import temp_router
from fastapi.security import OAuth2PasswordBearer

app = FastAPI()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


origins = [
    "*"
]

app.include_router(
	temp_router,
	prefix="/temp",
	tags=["temp"]
	)

conn=ConnectionConfig(
MAIL_FROM="narayanavishnukumarnvk@gmail.com",
MAIL_USERNAME="narayanavishnukumarnvk@gmail.com",
MAIL_PASSWORD="kumar321",
MAIL_PORT=587,
MAIL_SERVER="smtp.gmail.com",
MAIL_TLS=True,
MAIL_SSL=False
)



app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class retur(BaseModel):
	name2:str
	price2:int

class Int(BaseModel):
	d1:int

class details(BaseModel):
	name1:str
	price:int
	details:List[retur]=Field(...,description="list of retur schema")

class newBase(BaseModel):
	name:str
	idNum:str
	anotherDetails:List[Int]

class user(BaseModel):
	name:str
	age:str
	

@app.post("/form")
def fun1(username: str = Form(...), password: str = Form(...)):
	return username+" "+password

@app.post("/access")
def fun(details:user,count:int=Body(...)):
	return details.__dict__

@app.post("/temporary")
async def temporary(token: str = Depends(oauth2_scheme)):
	return {"token": token}
	

@app.post("/newone")
def fun2(name:user):
	client=ArangoClient(hosts="http://localhost:8529")
	db1=client.db("firstDb",username="root",password="arangodb")
	col=db1["student"]
	for doc in col:
		if(doc["name"]=="temporary" and doc["age"]=="infinity"):
			key=doc["_key"]
			col.delete(key)

	return JSONResponse({
		'status_code':status.HTTP_200_OK,
		'detail':"data accepted"
	})

class EmailSchema(BaseModel):
   email: List[EmailStr]

class contactAgent(BaseModel):
	name:str
	email:str
	phone:int
	address:str


@app.post("/email")
async def fun3(email:EmailSchema):
	email1=["narayanavishnukumar@gmail.com"]
	html="<div style='width:100px;height:100px;border:1px solid red;text-align:center;'>Hi from fastmail</div>"
	message=MessageSchema(
		subject="just trails",
		recipients=email1,
		body=html,
		subtype="html"
		)
	print(message)
	fm=FastMail(conn)
	await fm.send_message(message)
	return JSONResponse({
		'status_code':status.HTTP_200_OK,
		'detail':"data accepted"
	})


@app.post("/contactAgent")
async def contactfun(contactDetails:contactAgent):
	contact=contactDetails.__dict__
	html=f"<center><h1 style='color:blue;'>CLIENT DETAILS</h1></center><p>Name:{contact['name']}</p><p>Email:{contact['email']}</p><p>contact number:{contact['phone']}</p><p>Address:{contact['address']}</p><h2 style='margin-top:50px'>Thank You</h2><h3>Team Real Estate</h3>"
	msg=MessageSchema(
		subject="real estate client",
		recipients=["narayanavishnukumar@gmail.com"],
		body=html,
		subtype="html"	
	)
	fm=FastMail(conn)
	await fm.send_message(msg)
	return "details sent"

	

@app.post("/date")
def date_fun(input_data:datetime=Query(...,title="input_date",description="this api is for testing date input",example="year:month:day")):
	input_data=str(input_data)
	print(datetime.now())
	print(datetime.now().date())
	print(datetime.now().time())
	return JSONResponse({
		'status_code':status.HTTP_200_OK,
		'detail':input_data
	})




@app.post("/{itemName}")
def root(*,itemName:str=Path(...,title="Name of item",description="It is used to describe name of item"),d:int=Body(...,example={"name":"name1","password":"password1"}),total:details):
	total_all={}
	total_all=total.dict()
	total_all["item"]=itemName
	total_all["d"]=d
	print(total_all)
	return total_all

