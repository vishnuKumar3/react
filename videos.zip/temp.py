from fastapi import APIRouter,Query,status,UploadFile,File,Form
from fastapi.responses import JSONResponse,HTMLResponse
import shutil
from arango import ArangoClient


temp_router=APIRouter()


@temp_router.post("/add_user",response_class=HTMLResponse)
def add_user(name:str=Form(...),f:UploadFile=File(...)):
	result=f"{name} and {f.filename}"
	with open("dest/"+f.filename, "wb") as b:
		shutil.copyfileobj(f.file, b)
	return '''
		<html>
		<script>
			window.onload=function(){window.history.back();};
		</script>
		</html>
		'''

@temp_router.post("/database")
def database():
	client=ArangoClient(hosts="http://localhost:8529")
	db=client.db("Estate",username="root",password="arangodb")
	school=None
	if db.has_graph("school"):
		school=db.graph("school")
	else:
		school=db.create_graph("school")
	account=None
	if school.has_vertex_collection("account"):
		account=school.vertex_collection("account")
	else:
		account=school.create_vertex_collection("account")
	user=None
	if school.has_vertex_collection("user"):
		user=school.vertex_collection("user")
	else:
		user=school.create_vertex_collection("user")
	name=input("Enter the name:")
	account=account.insert({
		"name":name
	})
	user=user.insert({
		"name":name
	})
	account_user=None
	if school.has_edge_definition("account_user"):
		account_user=school.edge_collection("account_user")
	else:
		account_user=school.create_edge_definition(
			edge_collection="account_user",
			from_vertex_collections=["account"],
			to_vertex_collections=["user"]
			)
	account_user.insert({
	"_key":f"{account['_key']}_{user['_key']}",
	"_from":f"account/{account['_key']}",
	"_to":f"user/{user['_key']}"
	})
	
			




