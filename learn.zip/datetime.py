import datetime as dt
from datetime import timedelta
a=input("enter:")
#input format 2021-07-23 23:60:59
d=dt.datetime.strptime(a,"%Y-%m-%d %H:%M:%S")
d2=dt.datetime.today()
d4=d2+timedelta(minutes=40)
print(d2.date())
print(d2.time())
print(d2)
re=d2-d
print(re.days)
print(re.total_seconds())


