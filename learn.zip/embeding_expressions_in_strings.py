a=3
print("a value is %d"%a)
a=3
b=2
print("a value is {first} and b value is {second}".format(first=a,second=b))
a=3
b=2
print(f"a value is {a} and b value is {b}\n" f"{a}")
