from pydantic import BaseModel

class contactAgent(BaseModel):
	name:str
	email:str
	phone:int
	address:str
	
	
