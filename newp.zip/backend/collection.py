from database import access_db

db=access_db()
estate=None

if(db.has_graph("estate")):
	estate=db.graph("estate")
else:
	estate=db.create_graph("estate")

def get_vertex(vertex_name):
	if estate.has_vertex_collection(vertex_name):
		return estate.vertex_collection(vertex_name)
	else:
		return estate.create_vertex_collection(vertex_name)

building=get_vertex("building")
