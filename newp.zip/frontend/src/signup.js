export default function Signup(){
	return(
		<div id="signup" className="fixed w-full h-full flex flex-row justify-center items-center">
			<div id="signup_dialog" className="pt-5 pl-5 pb-10 bg-white rounded-xl w-5/6 lg:w-1/3">
				<center id="heading"><p>Signup</p></center>
				<p className="mt-10">Email:</p>
				<input type="email" placeholder="enter your email"/>
				<p>Password:</p>
				<input type="password" placeholder="enter your password"/><br/>
				<p>confirm Password:</p>
				<input type="password" required placeholder="retype the password"/><br/>
				<button className="mt-5 mr-5">signup</button>
				<button id="signup_close_button">close</button>
			</div>
		</div>
	);
}
