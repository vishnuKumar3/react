export default function Signup(){
	return(
		<div id="login" className="fixed w-full h-full flex flex-row justify-center items-center">
			<div id="login_dialog" className="pt-5 pl-5 pb-10 bg-white rounded-xl w-5/6 lg:w-1/3">
				<center id="heading"><p>Login</p></center>
				<p className="mt-10">Email:</p>
				<input type="email" placeholder="enter your email"/>
				<p>Password:</p>
				<input type="password" placeholder="enter your password"/><br/>
				<button className="mt-5 mr-5">login</button>
				<button id="login_close_button">close</button>
			</div>
		</div>
	);
}
